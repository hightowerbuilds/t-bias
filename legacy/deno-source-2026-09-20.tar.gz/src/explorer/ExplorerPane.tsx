import { createResource, createSignal, For, Show } from "solid-js";
import { joinPath, listDirectory, readTextFile, type DirEntry } from "../lib/fs";
import type { ExplorerPane as ExplorerPaneNode } from "../pane-tree";
import MarkdownPreview from "../preview/MarkdownPreview";

const MD_RE = /\.(md|markdown|mdown|mkd|mkdn)$/i;

export default function ExplorerPane(props: { pane: ExplorerPaneNode }) {
  const [path, setPath] = createSignal(props.pane.cwd ?? ".");
  const [entries] = createResource(path, listDirectory, { initialValue: [] });

  // Markdown preview: a file path being previewed (null = show the file list).
  const [previewPath, setPreviewPath] = createSignal<string | null>(null);
  const [content] = createResource(
    previewPath,
    async (p) => (p ? await readTextFile(p) : ""),
  );

  const open = (name: string, type: DirEntry["type"]) => {
    if (type === "directory") {
      setPath((p) => joinPath(p, name));
      return;
    }
    if (MD_RE.test(name)) setPreviewPath(joinPath(path(), name));
  };

  const goUp = () => {
    setPath((p) => {
      if (p === "" || p === ".") return ".";
      const parent = p.split("/").slice(0, -1).join("/");
      return parent || ".";
    });
  };

  return (
    <div class="explorer-pane">
      <Show
        when={previewPath()}
        fallback={
          <>
            <div class="explorer-header">
              <button onClick={goUp} disabled={path() === "."}>↑</button>
              <span class="explorer-path">{path()}</span>
            </div>
            <div class="explorer-list">
              <Show when={entries.loading}>
                <div class="explorer-empty">loading…</div>
              </Show>
              <Show when={entries.error}>
                <div class="explorer-empty err">{String(entries.error)}</div>
              </Show>
              <For each={entries()}>
                {(entry) => (
                  <div
                    class="explorer-row"
                    classList={{
                      directory: entry.type === "directory",
                      markdown: entry.type === "file" && MD_RE.test(entry.name),
                    }}
                    onClick={() => open(entry.name, entry.type)}
                  >
                    <span class="explorer-icon">
                      {entry.type === "directory"
                        ? "📁"
                        : entry.type === "symlink"
                        ? "🔗"
                        : MD_RE.test(entry.name)
                        ? "📝"
                        : "📄"}
                    </span>
                    <span class="explorer-name">{entry.name}</span>
                  </div>
                )}
              </For>
            </div>
          </>
        }
      >
        <Show
          when={!content.loading}
          fallback={<div class="explorer-empty">loading…</div>}
        >
          <Show
            when={!content.error}
            fallback={
              <div class="md-preview">
                <div class="md-toolbar">
                  <button class="md-back" onClick={() => setPreviewPath(null)}>
                    ← Files
                  </button>
                </div>
                <div class="explorer-empty err">{String(content.error)}</div>
              </div>
            }
          >
            <MarkdownPreview
              path={previewPath()!}
              content={content() ?? ""}
              onClose={() => setPreviewPath(null)}
            />
          </Show>
        </Show>
      </Show>
    </div>
  );
}
