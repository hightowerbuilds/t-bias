import { createMemo, createSignal, For } from "solid-js";
import { renderMarkdown } from "../lib/markdown";

// Rendered Markdown preview with a live font-size control and swappable display
// "styles" (theme skins). The parser output is one clean HTML tree; each theme
// just re-skins it via a CSS class on the scroll container — so adding a style
// is a CSS-only change plus one entry in THEMES.

export type MdTheme = "default" | "newspaper" | "invoice" | "diagram";

const THEMES: { id: MdTheme; label: string }[] = [
  { id: "default", label: "Default" },
  { id: "newspaper", label: "Newspaper" },
  { id: "invoice", label: "Invoice" },
  { id: "diagram", label: "Diagram" },
];

const MIN_SIZE = 9;
const MAX_SIZE = 40;
const DEFAULT_SIZE = 15;

export default function MarkdownPreview(props: {
  path: string;
  content: string;
  onClose: () => void;
}) {
  const [size, setSize] = createSignal(DEFAULT_SIZE);
  const [theme, setTheme] = createSignal<MdTheme>("default");
  const html = createMemo(() => renderMarkdown(props.content));

  const bump = (delta: number) =>
    setSize((s) => Math.max(MIN_SIZE, Math.min(MAX_SIZE, s + delta)));

  const fileName = () => props.path.split("/").pop() || props.path;

  return (
    <div class="md-preview">
      <div class="md-toolbar">
        <button class="md-back" onClick={props.onClose} title="Back to files">
          ← Files
        </button>
        <span class="md-title" title={props.path}>{fileName()}</span>
        <div class="md-controls">
          <select
            class="md-theme-select"
            value={theme()}
            onChange={(e) => setTheme(e.currentTarget.value as MdTheme)}
            title="Display style"
          >
            <For each={THEMES}>
              {(t) => <option value={t.id}>{t.label}</option>}
            </For>
          </select>
          <div class="md-font">
            <button onClick={() => bump(-1)} title="Smaller">A−</button>
            <button onClick={() => setSize(DEFAULT_SIZE)} title="Reset size">{size()}</button>
            <button onClick={() => bump(1)} title="Larger">A+</button>
          </div>
        </div>
      </div>
      <div class={`md-scroll md-theme-${theme()}`}>
        <div class="md-body" style={{ "font-size": `${size()}px` }} innerHTML={html()} />
      </div>
    </div>
  );
}
