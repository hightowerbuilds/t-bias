mod activity;
mod config;
mod controller;
mod db;
mod explorer;
mod fs;
mod gamepad;
mod input;
mod markdown;
mod menus;
mod mouse;
mod pane_tree;
mod prompt_panel;
mod prompts;
mod terminal;
mod terminal_pane;
mod terminal_view;
mod text_field;
mod workspace;
mod workspace_view;

use gpui::{prelude::*, px, size, App, Application, Bounds, WindowBounds, WindowOptions};
fn main() {
    if let Some(path) = std::env::args()
        .skip_while(|a| a != "--controller-probe")
        .nth(1)
    {
        if let Err(e) = controller::renderer::probe(&path) {
            eprintln!("Controller probe: {e:#}");
            std::process::exit(1);
        }
        return;
    }
    if std::env::args().any(|a| a == "--activity-probe") {
        activity::collector::probe();
        return;
    }
    config::init_logging();
    Application::new().run(|cx: &mut App| {
        menus::install(cx);
        let initial_size = if std::env::args().any(|a| a == "--compact") {
            size(px(640.), px(420.))
        } else {
            size(px(1280.), px(820.))
        };
        let bounds = Bounds::centered(None, initial_size, cx);
        let window = cx
            .open_window(
                WindowOptions {
                    window_bounds: Some(WindowBounds::Windowed(bounds)),
                    window_min_size: Some(size(px(640.), px(420.))),
                    window_background: gpui::WindowBackgroundAppearance::Transparent,
                    ..Default::default()
                },
                |_, cx| cx.new(workspace_view::WorkspaceView::new),
            )
            .expect("failed to open window");
        window
            .update(cx, |_, window, cx| {
                let root = cx.weak_entity();
                window.on_window_should_close(cx, move |_, cx| {
                    let _ = root.update(cx, |root, cx| root.prepare_close(cx));
                    true
                });
            })
            .unwrap();
        if std::env::args().any(|a| a == "--smoke-test") {
            window
                .update(cx, |view, _, cx| view.start_smoke(cx))
                .unwrap();
        }
        if std::env::args().any(|a| a == "--controller-smoke") {
            window
                .update(cx, |view, _, cx| view.start_controller_smoke(cx))
                .unwrap();
        } else if std::env::args().any(|a| a == "--controller") {
            window
                .update(cx, |view, _, cx| view.open_controller(cx))
                .unwrap();
        }
        if std::env::args().any(|a| a == "--activity-smoke") {
            window
                .update(cx, |view, _, cx| view.start_activity_smoke(cx))
                .unwrap();
        } else if std::env::args().any(|a| a == "--activity-monitor") {
            window
                .update(cx, |view, _, cx| view.open_activity(cx))
                .unwrap();
        }
        cx.on_window_closed(|cx| {
            if cx.windows().is_empty() {
                cx.quit();
            }
        })
        .detach();
        cx.activate(true);
    });
}
